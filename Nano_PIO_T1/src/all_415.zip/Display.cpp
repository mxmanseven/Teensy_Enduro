
//#include <LiquidCrystal.h>
//#include "display.h"
//#include <string.h>




//Display::Display()
  //lcd(2, 3, 4, 5, 6, 7)
//{
  // set up the LCD's number of columns and rows:
//  lcd.begin(20, 4);
//}

//void printK(String st)
//{
 // lcd.clear();
  //lcd.print(st);
//}




