#ifndef DISPLAY_H_
#define DISPLAY_H_

//#include <Arduino.h>
//#include <LiquidCrystal.h>
//#include <string.h>

// LCD geometry
//const int LCD_COLS = 20;
//const int LCD_ROWS = 4;

//class Display
//{
  //public:
    //Display();
    //LiquidCrystal lcd;

    void printK(String st);
//};
#endif

