ioClass
=======

This directory contains a subdirectory for each i/o class that contains
examples for that specific i/o class.

The hd44780examples directory under each i/o class subdirectory contains
i/o class specific wrapper sketches for the special purpose sketches under
examples/hd44780examples.
